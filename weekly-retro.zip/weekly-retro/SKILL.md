---
name: weekly-retro
description: |
  Weekly retrospective adapted from Garry Tan's gstack /retro. Runs a structured retro across EOS Practice, AirChAiR, and Eden — pulling from Calendar, Gmail, Drive, debriefs, and conversation history. Surfaces what shipped, what stalled, patterns, energy allocation (D&E lens), and week-over-week trends. Trigger on: "retro", "weekly retro", "retrospective", "what did I ship this week", "weekly review", "week in review", "Friday retro", "end of week review", "how did my week go", "review my week", "what's the pattern". Also on Friday wrap-up requests. Do NOT trigger for Gap & Gain (daily), session debriefs (per-session), or morning briefings. This is the WEEKLY zoom-out.
---

# Weekly Retro — Three-Lane Retrospective

Adapted from Garry Tan's gstack /retro (MIT License). The original analyzes git commits, PR sizes, and code hotspots. This version runs the same structured retrospective discipline across Duke's three vocational lanes using his actual calendar, email, drive, and debrief data.

## Why This Skill Exists

Duke has Gap & Gain for daily wins and session debriefs for individual EOS sessions. What he doesn't have is a weekly zoom-out that crosses all three lanes and asks: "What's the pattern?" The gstack retro is powerful because it doesn't just ask "what happened" — it measures, compares week-over-week, and tracks streaks. This version brings that discipline to Duke's non-engineering work.

## Step 1: Gather Raw Data

Pull from all available sources for the past 7 days (or the period Duke specifies):

**Google Calendar:** List all events from the past week. Categorize each by lane:
- EOS: Client sessions (Focus Day, VB1, VB2, Quarterly, Annual), 90-Minute Meetings, prospect meetings, EOS community calls
- AirChAiR: Cohort sessions, curriculum work, marketing/content time, prospect conversations
- Eden: Board meetings, Triad/Chapter facilitation, retreat planning, formation conversations
- Practice Ops: Admin, invoicing, scheduling, travel, skill-building, AI tool time
- Personal: Blocked as personal — count but don't detail

**Gmail:** Search for sent emails from the past week. Count by category:
- Client communications (responses, follow-ups, prep emails)
- Prospect outreach (new conversations, referral requests)
- AirChAiR communications
- Eden communications
- Administrative

**Google Drive:** Check for recently modified files in EOS client folders, AirChAiR folders, Eden folders.

**Session Debriefs:** Check if any eos-session-debrief entries were logged this week.

**Conversation History:** Review this week's Claude conversations for completed tasks, decisions made, and deliverables produced.

## Step 2: Compute Weekly Metrics

Build a summary table:

```
WEEK OF [date range]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EOS Practice
  Sessions delivered:     [count]
  90-Min Meetings:        [count]
  Prospect touches:       [count]
  Client emails sent:     [count]

AirChAiR
  Cohort sessions:        [count]
  Content pieces created: [count]
  Prospect conversations: [count]

Eden
  Meetings/calls:         [count]
  Formation hours:        [count]

Practice Ops
  Admin hours (est):      [hours]
  AI/skill-building hrs:  [hours]

TOTALS
  Revenue-generating hrs: [hours]
  Prospect-facing hrs:    [hours]
  Building/creating hrs:  [hours]
  Admin/ops hrs:          [hours]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## Step 3: Time Distribution

Estimate how Duke's week broke down by lane. Present as percentages:

```
TIME ALLOCATION
  EOS Practice:    ██████████████░░░░░░ 65%
  AirChAiR:        ████░░░░░░░░░░░░░░░░ 15%
  Eden:            ██░░░░░░░░░░░░░░░░░░  8%
  Practice Ops:    ███░░░░░░░░░░░░░░░░░ 12%
```

Flag if time allocation is significantly different from what Duke intends. If he's spending 12% on admin but wants to be under 5%, name it.

## Step 4: Ship of the Week

Identify the single most impactful thing Duke shipped or delivered this week. "Shipped" means: a session delivered, a cohort session run, a design brief completed, a prospect converted, a piece of content published, a skill created, a decision made and communicated.

Name it explicitly: "SHIP OF THE WEEK: [what it was] for [who it served]."

If nothing clearly shipped, say so — and ask why. A week with no deliverables is data, not a failure.

## Step 5: Energy Analysis (Delegate & Elevate Lens)

Using the Delegate & Elevate framework, assess where Duke's time went this week:

- **Love It / Great At It:** Teaching-facilitating-coaching leadership teams, deep research, strategic thinking, 1-on-1 coaching conversations, content creation
- **Like It / Good At It:** Session prep, prospect conversations, curriculum design
- **Don't Like It / Good At It:** Admin, scheduling, follow-up email chains, invoicing
- **Don't Like It / Not Good At It:** Cold outreach, social media engagement for engagement's sake, tasks requiring sustained Galvanizing/Enablement energy

Flag any week where Duke spent more than 20% of his time in the bottom two quadrants. Name what should be delegated and to whom (Caroline, a VA, automation, a skill).

## Step 6: Patterns & Trends

If this is the second or later retro, compare week-over-week:

- **What increased?** More sessions? More prospect activity? More admin?
- **What decreased?** Fewer client touches? Less content creation?
- **What's the streak?** Track consecutive weeks of: sessions delivered, content published, prospect conversations held, cohort sessions run.
- **Energy trend:** Is Duke trending toward more Love It/Great At It work or less?

Name the pattern in one sentence: "The pattern this week is [X]."

## Step 7: Stuck List

What stalled this week? For each stalled item:
- What it is
- Why it stalled (waiting on someone? Duke avoiding it? Not enough time? Wrong priority?)
- Whether it matters enough to carry forward or should be dropped

Be honest about the "Duke avoiding it" category. His QS2 means he won't jump into unproven approaches — but sometimes that resistance is protecting him from wasted effort, and sometimes it's keeping him from necessary action. Name which one.

## Step 8: Next Week Preview

Pull next week's calendar and identify:
- Sessions to deliver (with client names)
- Prospect meetings
- Deadlines (Rock due dates, content commitments)
- Open blocks that could be used for deep work

Flag any day that looks overscheduled or any day with no client-facing work.

## Step 9: Write the Narrative

Produce a retro document (saved as markdown) structured as:

```
# Weekly Retro — [Date Range]

## The Headlines
[2-3 sentence summary of the week — what defined it]

## Ship of the Week
[Name it]

## By the Numbers
[Metrics table from Step 2]

## Time Allocation
[Distribution from Step 3]

## Energy Check
[D&E assessment from Step 5]

## Patterns
[Week-over-week trends from Step 6, or "First retro — baseline established"]

## What Stalled
[Stuck list from Step 7]

## Next Week
[Preview from Step 8]

## One Honest Sentence
[The thing Duke needs to hear but might not want to — stated with respect but without softening]
```

The "One Honest Sentence" is the retro's most important line. It should be the observation that Duke's FF9 thoroughness might cause him to bury in data. Name it plainly.

## Global Mode: `/retro global`

If Duke says "retro global" or "retro across everything" or "big picture retro," run the retro across all three lanes simultaneously and add a cross-lane analysis:

- **Where are the lanes reinforcing each other?** (e.g., an AirChAiR insight that improved an EOS session)
- **Where are they competing for Duke's time?** (e.g., Eden board work crowding out prospect conversations)
- **Vocational alignment check:** Is the overall week consistent with Duke's throughline — creating conditions for people to grow, learn, and change?
- **What would an outside observer say Duke's primary job is, based only on how he spent his time this week?** If the answer doesn't match what Duke wants it to be, that's the most important finding.

## Retro History

If possible, save retro summaries so future retros can reference them. Append a dated JSON summary to a running log:

```json
{
  "week": "2026-W19",
  "sessions_delivered": 3,
  "prospect_touches": 5,
  "ship_of_week": "Delivered Q2 Quarterly for [client]",
  "energy_assessment": "78% Love/Great, 22% bottom quadrants",
  "pattern": "Prospect activity increasing week over week",
  "honest_sentence": "[the thing]"
}
```

This enables trend tracking over months, not just weeks.
