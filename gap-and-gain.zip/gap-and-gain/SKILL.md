---
name: gap-and-gain
description: Duke Revard's nightly ritual from Sullivan & Hardy's *The Gap and the Gain*. Capture today's 3 wins (GAINs), set 3 prioritized wins for tomorrow, append a dated row to the existing **Gap & Gain - 3 Daily Wins - 2024 Log** Google Doc table. Trigger on "gap and gain", "nightly ritual", "3 wins", "three wins", "log my wins", "GAIN journal", "wrap up the day", "end of day", "EOD reflection", "wind down", "today's wins", "journal my day", "log my day", or any phrasing signaling Duke is closing the day. Pulls tomorrow candidates from Trello, Calendar, recent EOS Docs, and chat history (same sources as morning-briefing); proposes 4–6 for Duke to pick 3. Chronological table — newest row at the bottom, oldest at the top. Do NOT use for session debriefs (eos-session-debrief) or morning prep (morning-briefing).
---

# Gap and Gain — Nightly Ritual

The single highest-leverage hour in Duke's day is the hour before sleep. The Gap and the Gain prescribes a specific use of it: record three wins from today, set three intended wins for tomorrow, put the phone down. The mechanism is partly priming (he falls asleep with GAINs as the last input) and partly broaden-and-build (gratitude opens cognition; anxiety narrows it). This skill runs that ritual and writes it down so it compounds.

## What this skill produces

A new dated row appended to the **bottom** of the 3-column table inside Duke's existing Google Doc:

- **Title:** `Gap & Gain - 3 Daily Wins - 2024 Log`
- **File ID:** `1jKCHPRiQTreJT_lf-hejSWnR57Q0_FCupDsRCdTxM3Q`
- **URL:** `https://docs.google.com/document/d/1jKCHPRiQTreJT_lf-hejSWnR57Q0_FCupDsRCdTxM3Q/edit`

Each row has exactly three cells:

| Date | Wins - Today | Anticipated - Tomorrow |
| ---- | ------------ | ---------------------- |
| 05/02/2026 | Time in John 17, Walk & workout, Discerning AirChAiR pacing | Worship at New River, Trusting God by ceasing, Reading for leisure |

**Format rules:**
- **Date:** `MM/DD/YYYY` zero-padded (e.g., `05/02/2026`, `11/03/2026`, `01/15/2027`). The original log used `M/D/YY` with no zero padding; this is a deliberate upgrade for sortability and visual consistency.
- **Wins - Today** and **Anticipated - Tomorrow** cells: comma-separated phrases in a single line. No bullets. No line breaks inside cells. The table is the visual structure; cells stay tight.
- **Voice:** Duke's existing entries are crisp and clipped — "workout, MCE, Lily Kappa News". Keep that register. Verbs first, abbreviations welcome.

The table is **chronological top-to-bottom** — oldest first, newest last. New entries fill the next empty row. Do NOT prepend to the top. Do NOT reverse the order. The doc has ~70 pre-formatted empty rows below the last entry; just fill the next one.

## Workflow

### Step 1 — Pull tomorrow's-wins context (do this BEFORE asking Duke anything)

Run these four pulls in whatever order is fastest. They mirror the morning-briefing skill's sources, so look there if you need detail on the queries.

1. **Trello** (Claude in Chrome) — board `https://trello.com/b/MktR462s/eos-next-actions`. Read cards from **Doing** and **90 Day World** lists. Skip Done.
2. **Google Calendar** — list events for **tomorrow** in `America/Chicago`. Capture titles, times, attendee counts, and any session indicators (Quarterly, Annual, Focus Day, VB1, VB2, 90-Minute Meeting).
3. **Google Drive** — search EOS client folder `1AeH8dsGe3fedCfSjCwROpIzDNspTDCQr` for docs modified in the last 3 days. Recently-touched docs signal active client work that may need follow-up.
4. **Conversation history** — `recent_chats` (last 3) plus `conversation_search` for "follow up", "pending", "next step", "tomorrow". Surface only items that are clearly actionable and not already represented in Trello or Calendar.

If Chrome isn't available, skip Trello and say so honestly in Step 3 — never fabricate cards. The other three sources are usually enough to propose 4–6 candidates.

### Step 2 — Ask Duke for today's wins

Send a single short message. Don't pepper him with sub-questions. Duke uses Wispr Flow and will dictate one block:

> *"Wrapping the day. What were your 3 wins today? Dictate when ready — tell me what landed, what you finished, what moved. I'll pull tomorrow's candidates from your Trello, calendar, and active docs while you talk."*

Wait for his response. It will arrive as one block of dictated text.

### Step 3 — Parse today's wins and propose tomorrow's

Parse Duke's dictation into 3 short comma-separable phrases. **Light editing only** — fix homophones and obvious dictation errors, but preserve his voice. Then collapse to a single comma-separated string that fits one table cell.

Example:
- Input: "I had a great time in John 17 this morning, then I did my walk and workout, and I made the call to print AirChAiR sessions one at a time instead of rushing the whole booklet."
- Parsed cell: `Time in John 17, Walk & workout, Discerning AirChAiR pacing (sessions 1 at a time)`

Then propose **4–6 candidates for tomorrow's wins**, drawn from the Step 1 pulls. Rank them by what would matter most based on:

- **Tomorrow's calendar load first.** If tomorrow has an EOS session (Focus Day, Quarterly, VB1, VB2, Annual, 90-Minute Meeting), the prep for that session is almost always Win #1.
- **Active "Doing" Trello cards** — these are Duke's current commitments.
- **90 Day World Rocks** — quarter-end advancement.
- **Stale "Waiting on Others" items** older than 7 days that Duke could nudge.
- **Pending follow-ups** from recent conversations.

Present back like this:

```
Here's today, captured:

| Date | Wins - Today |
| ---- | ------------ |
| 05/02/2026 | [parsed comma-separated phrase] |

For tomorrow, here's what's pulling on you. Pick 3 or rewrite:

1. [Candidate — one-line why-it-matters]
2. [Candidate — one-line why-it-matters]
3. [Candidate — one-line why-it-matters]
4. [Candidate — one-line why-it-matters]
5. [Candidate — one-line why-it-matters]
6. [Candidate — one-line why-it-matters]
```

Wait for Duke to pick 3, edit, or replace.

### Step 4 — Write the row directly into the doc

**Direct write is the default and required behavior. Don't reach for paste-back unless Chrome is genuinely unreachable.**

#### One-time setup (verify on first run)

The Chrome extension needs `docs.google.com` in its allowed domains. If it's not there, every direct-write attempt will return `permission_required`. Duke grants this once via the Chrome extension icon → Manage permissions → add `docs.google.com`. After that, Path A works for every future invocation.

#### Path A — Chrome direct-write (always try first)

1. `tabs_context_mcp` to confirm a tab is available. If this times out, see "Failure modes" below.
2. Navigate to `https://docs.google.com/document/d/1jKCHPRiQTreJT_lf-hejSWnR57Q0_FCupDsRCdTxM3Q/edit`. If this returns `permission_required`, see "Failure modes."
3. Wait ~4 seconds for the doc to fully render.
4. Take a screenshot. Locate the data table — header row reads `Date | Wins - Today | Anticipated - Tomorrow`. Find the first empty row below the most recent dated entry.
5. Click into the **Date** cell of that empty row.
6. Type the date in `MM/DD/YYYY` format.
7. Press `Tab`. Type the comma-separated Wins-Today string.
8. Press `Tab`. Type the comma-separated Anticipated-Tomorrow string.
9. Click outside the table on whitespace below to deselect — Google Docs autosaves.
10. Take a verification screenshot.

Use `browser_batch` to stack `navigate` + `wait` + `screenshot` in one round trip. Stack `left_click` + `type` + `key Tab` + `type` + `key Tab` + `type` in another round trip after coordinates are known.

#### Failure modes — diagnose and tell Duke specifically

When Path A fails, the goal is to name *why* so Duke can fix it once and the ritual stops breaking. Don't just say "Chrome failed."

- **`permission_required` on navigate** → "Chrome extension doesn't have `docs.google.com` permission yet. Grant it via the extension icon → Manage permissions, then re-trigger the skill. One-time fix."
- **`tabs_context_mcp` times out** → "Chrome extension isn't connected to this Claude session. Open the extension popup and check the connection state. Once connected, re-trigger."
- **Doc loads but table not found** → "Doc structure shifted — the table I expect isn't there. Open the doc and confirm the 3-column table still exists with header `Date | Wins - Today | Anticipated - Tomorrow`. Send me the new structure if it changed."
- **Table found but no empty rows** → see edge case "Table is full" below.
- **Generic Chrome error** → make ONE retry. If it fails again, name the error message to Duke verbatim, then Path B.

In ALL failure modes, after stating the diagnosis, fall to Path B for tonight's entry — but lead with the fix, not the paste-back.

#### Path B — Paste-back (rare, emergency only)

This path exists so the ritual never gets stuck, NOT as the default. Use only after Path A has been attempted and a specific failure mode has been named to Duke.

Provide each cell's content separately so Duke can paste cell-by-cell:

- **Date:** `05/02/2026`
- **Wins - Today:** `Time in John 17, Walk & workout, Discerning AirChAiR pacing`
- **Anticipated - Tomorrow:** `Worship at New River, Trusting God by ceasing, Reading for leisure`

Then the doc URL.

### Step 5 — Close the loop

Send a short confirming message with the doc link:

> *"Logged. [link to doc]. Phone down."*

That last beat — *"phone down"* — is doctrinally important. The book is explicit that the ritual fails if the phone goes back into rotation after journaling. Don't drop it.

## Voice and tone notes

- Duke is reflective and direct. Match that. No cheerleading, no "amazing wins!"
- Cells are TIGHT. Comma-separated phrases in a single line. Earlier draft of this skill used bullets; this format is one-liners. Adjust accordingly.
- Wins should sound like Duke wrote them. Verbs first, specifics over generalities ("Closed Wilks Q1 prep" beats "Made progress on Wilks").
- Tomorrow's candidates should each have a one-line why **outside the table** (in the Step 3 message back to Duke). Duke is Kolbe FF9 and wants the reason. The doc itself only stores the comma-separated phrase.
- If today was hard and Duke says so, don't paper over it. Honest reframe, not denial. If a "win" he names is "I survived a brutal Friday," let it stand.
- Skip emoji, exclamation points, and hype words. Duke's voice runs on subtraction.

## Edge cases

- **Duke gives 2 or 4 wins** — capture what he gives, then ask once: "Keep all 4 or trim to 3?" Default to 3 if he doesn't answer. The ritual is 3 by design.
- **Duke can't think of any wins** — push back gently. "Even a hard day has 3 GAINs. What did you finish? Who did you help? What did you learn?" If he genuinely lands on zero, log "Survived" as Win 1 and ask about 2 more. Don't fabricate.
- **Tomorrow's calendar is empty** — propose candidates from Trello "Doing" + Rocks + stale Waiting on Others. An empty calendar usually means clarity-break or content-creation day; lean into that.
- **Doc is missing or moved** — search Drive for `"Gap & Gain"` or `"Gain Journal"`. If genuinely gone, fall back to Path B and tell Duke: "Doc not found at the expected ID — paste this somewhere safe and let me know where the new home is so I can update the skill."
- **Table is full** (no empty rows left) — tell Duke once: "The pre-formatted table is full. Want me to add empty rows in the next run, or convert to year-stamped sub-tables?" Don't auto-extend.
- **Duke runs the skill twice in one day** — append a second row with the same date. Don't overwrite the first. Two entries on one date is fine — life happens.
- **Duke says "skip tomorrow's wins, just log today's"** — write only the Date and Wins-Today cells. Leave Anticipated-Tomorrow empty. Don't argue.
- **Duke pastes the wins inline at trigger time** ("Today's wins were X, Y, Z. Log it.") — skip Step 2's interview, go straight to Step 3 with the wins he gave, then propose tomorrow's candidates.
- **Chrome loop trap** — if Path A retries fail more than twice, switch to Path B immediately. Never sacrifice the "phone down" cadence to debug browser automation.

## What this skill does NOT do

- Does not capture session debriefs — that's `eos-session-debrief`.
- Does not produce the morning brief — that's `morning-briefing`.
- Does not coach Duke through the Experience Transformer or other Gap/Gain frameworks. This skill is the *nightly ritual only*.
- Does not write to Trello, send emails, or update calendars based on tomorrow's wins. The 3 priorities are journal commitments, not task-system writes.
- Does not modify or migrate older entries in the doc. Only appends a new row at the bottom.
- Does not change the doc's title or structure. The "2024 Log" name is now historical — Duke chose to keep the existing doc and let it span years rather than spawn a new file.
