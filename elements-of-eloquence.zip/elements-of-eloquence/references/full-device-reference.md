# The Elements of Eloquence — Complete Reference

**Source:** Mark Forsyth, *The Elements of Eloquence: Secrets of the Perfect Turn of Phrase* (Icon Books, 2013; Berkley/Penguin, 2014). 39 chapters. ~224 pages.

**Purpose of this document:** Background reference for converting into a Claude skill that helps Duke write more memorable LinkedIn posts, prospect emails, V/TO language, Eden material, and Three Uniques scripts. Every claim below is sourced; confidence is noted where it matters.

---

## Executive Summary

Forsyth's book covers **39 rhetorical "schemes"** — the patterns of word arrangement that make a phrase memorable independent of its meaning. His thesis is that great lines ("To be or not to be," "Bond, James Bond," "It was the best of times, it was the worst of times") are not memorable because of profundity. They are memorable because they obey ancient structural formulas the Greeks systematized and Shakespeare exploited. Master the formulas and you can produce memorable phrases on demand.

The book's 39 chapters cover ~42 distinct devices (a few chapters bundle related figures). They divide functionally into eight families: **repetition** (sound or word), **structural parallelism**, **word-order disruption**, **substitution and reference**, **wit and twist**, **magnification and diminishment**, **audience-engaging tricks**, and **versification**.

Confidence overall: **HIGH** on chapter list and Forsyth's headline definitions (5+ independent sources corroborate); **MEDIUM-HIGH** on his specific examples (Wikipedia + reviewer blogs cite directly); **MEDIUM** on his idiosyncratic edge cases (e.g., his unusual "Prolepsis" definition, where Forsyth picks one of five classical meanings and runs with it).

The single most useful insight for business writing: **almost every memorable phrase combines two or three of these devices simultaneously.** "Bond, James Bond" is diacope + isocolon. "Liberté, égalité, fraternité" is tricolon + isocolon + assonance. Stacking is the actual craft.

---

## Quick-Reference Table — All 39 Chapters

| # | Device | One-Line Definition | Famous Example |
|---|--------|---------------------|----------------|
| 1 | Alliteration | Same opening consonant in nearby words | "Tiger, tiger, burning bright" |
| 2 | Polyptoton | Same root, different grammatical forms | "Please please me" |
| 3 | Antithesis | Opposites in parallel structure | "It was the best of times, it was the worst of times" |
| 4 | Merism | Naming the parts to mean the whole | "Ladies and gentlemen" / "Heaven and earth" |
| 5 | Blazon | Merism stretched to inventory a beloved | The Song of Songs body-by-body description |
| 6 | Synaesthesia | One sense described in another's terms | "Music that stinks to the ear" |
| 7 | Aposiopesis | Trailing off mid-sentence on purpose | "Why I oughta…" / "If only…" |
| 8 | Hyperbaton | Wrong word order on purpose | "Stone walls do not a prison make" |
| 9 | Anadiplosis | Last word of clause = first word of next | "Fear leads to anger. Anger leads to hate." |
| 10 | Periodic Sentence | Sentence whose meaning isn't complete until the final clause | Kipling's "If—" |
| 11 | Hypotaxis / Parataxis / Polysyndeton / Asyndeton | Subordinate-heavy / short-and-simple / "and…and…and" / commas-only | "I came, I saw, I conquered" (asyndeton) |
| 12 | Diacope | Word repeated with one or two words between | "Bond, James Bond" |
| 13 | Rhetorical Question | Question not seeking a real answer | "Shall I compare thee to a summer's day?" |
| 14 | Hendiadys | Adjective+noun → noun and noun | "Sound and fury" (instead of "furious sound") |
| 15 | Epistrophe | Same word ending successive clauses | "…of the people, by the people, for the people" |
| 16 | Tricolon | Three parallel parts | "Liberté, égalité, fraternité" |
| 17 | Epizeuxis | Same word repeated immediately | "Location, location, location" |
| 18 | Syllepsis | One word governing two phrases with different meanings each time | "Make love not war" |
| 19 | Isocolon | Two (or more) clauses of equal length and matching structure | "Roses are red, violets are blue" |
| 20 | Enallage | Deliberate grammatical "mistake" | "Mistah Kurtz — he dead" |
| 21 | Versification | Meter and verse forms (iambic pentameter, etc.) | "Shall I com-PARE thee TO a SUM-mer's DAY" |
| 22 | Zeugma | One verb governs multiple clauses | "I lost my keys and my mind" |
| 23 | Paradox | Statement that seems false but reveals truth | "I can resist anything except temptation" |
| 24 | Chiasmus | A-B-B-A reversal of structure | "Ask not what your country can do for you…" |
| 25 | Assonance | Repeated vowel sounds | "The rain in Spain falls mainly on the plain" |
| 26 | The Fourteenth Rule | Use a weirdly specific number for emphasis | "Seven habits" / "Five love languages" |
| 27 | Catachresis | Deliberately "wrong" word forced into use | "I will speak daggers" |
| 28 | Litotes | Affirm by denying the opposite | "Not bad" / "I wouldn't say no" |
| 29 | Metonymy & Synecdoche | Use a connected thing / a part to mean the whole | "The White House said…" / "All hands on deck" |
| 30 | Transferred Epithet | Adjective attached to "wrong" noun | "A sleepless night" / "A condemned cell" |
| 31 | Pleonasm | Deliberately redundant words | "Free gift" / "ATM machine" / "I saw it with my own eyes" |
| 32 | Epanalepsis | Same word at the start AND end | "Man's inhumanity to man" |
| 33 | Personification | Giving human qualities to non-human things | "Justice is blind" |
| 34 | Hyperbole | Calculated exaggeration | "I've told you a million times" |
| 35 | Adynaton | Hyperbole pushed to the impossible | "When pigs fly" / "When hell freezes over" |
| 36 | Prolepsis | Pronoun used before its noun (Forsyth's preferred sense) | "They fuck you up, your mum and dad" — Larkin |
| 37 | Congeries | A pile-up of nouns or adjectives | "The cloud-capped towers, the gorgeous palaces, the solemn temples…" |
| 38 | Scesis Onomaton | A sentence with no main verb | "Space: the final frontier" |
| 39 | Anaphora | Same word(s) starting successive clauses | "We shall fight on the beaches, we shall fight on the landing grounds…" |

Sources for the table: Wikipedia's full article on the book, Barnes & Noble's published TOC, the Internet Archive full-text scan, and Goodreads/blog summaries that cite the book directly. **Confidence: HIGH** on every row.

---

## Functional Index — "I want to write a phrase that…"

**…sticks in the ear via sound:** Alliteration, Assonance, Versification (rhythm).

**…sticks via repetition of words:** Polyptoton, Anadiplosis, Diacope, Epistrophe, Anaphora, Epizeuxis, Epanalepsis.

**…sounds balanced and authoritative:** Antithesis, Isocolon, Tricolon, Chiasmus, Periodic Sentence, Polysyndeton.

**…sounds urgent or breathless:** Asyndeton, Parataxis, Aposiopesis.

**…is ornate, literary, "elevated":** Hypotaxis, Hyperbaton, Hendiadys, Catachresis, Synaesthesia, Personification, Blazon, Merism, Congeries.

**…lands a joke or a twist:** Syllepsis, Zeugma, Paradox, Adynaton, Enallage, Litotes.

**…reframes by part/whole/proxy:** Metonymy, Synecdoche, Transferred Epithet, Hendiadys.

**…amplifies or downplays:** Hyperbole, Adynaton, Litotes, Pleonasm, Congeries, The Fourteenth Rule.

**…directly engages the reader:** Rhetorical Question, Aposiopesis, Prolepsis.

---

## Detailed Entries (Chapter Order)

Each entry: **Definition** (Forsyth's framing) → **Example** (his canonical example, attributed) → **How it works** → **When to use in business writing**.

### 1. Alliteration

**Definition:** Repeating the opening consonant sound of nearby words. The classical "flowers of rhetoric" started here because English ears are tuned by Anglo-Saxon poetry to hear alliteration as elevated.

**Forsyth's example:** *"Whereat, with blade, with bloody blameful blade, / He bravely broached his boiling bloody breast"* — Shakespeare, *A Midsummer Night's Dream* (deliberately overdone for comic effect by Pyramus). His more elegant illustration: *"So we beat on, boats against the current, borne back ceaselessly into the past"* — Fitzgerald, *The Great Gatsby* (cited via reviewer cross-reference).

**How it works:** Two or three is enough. Four starts to feel like a tongue-twister. The trick is to pick a word that earns the alliteration so the reader doesn't notice the device — they just remember the phrase.

**Business-writing use:** Headlines, taglines, three-word brand promises. EOS examples in the wild: *"Vision, Traction, Healthy"* uses a soft form (V-T sounds at the start of two of three). LinkedIn carousel titles benefit from it heavily.

---

### 2. Polyptoton

**Definition:** Using the same root word in different grammatical forms. *Wretched* and *wretchedness*. *Please* (verb) and *please* (intensifier).

**Forsyth's example:** *"Grace me no grace, nor uncle me no uncle: / I am no traitor's uncle; and that word 'grace' / In an ungracious mouth is but profane"* — Shakespeare, *Richard II*. Pop example: *"Please please me"* — The Beatles (please as imperative + please as infinitive verb).

**How it works:** Polyptoton is so subtle most readers don't notice it, but it creates an undertow of repetition that makes a phrase feel inevitable. Distinct from antanaclasis (same word, different *meaning*). Polyptoton is same root, different *form*.

**Business-writing use:** "We don't just sell systems. We systematize the way you sell." (sell/sell, system/systematize). Excellent for value-prop one-liners. Forsyth notes Shakespeare uses it constantly.

---

### 3. Antithesis

**Definition:** Two opposites placed in parallel structure for contrasting effect. The contrast must be both *semantic* (meaning) and *syntactic* (structure).

**Forsyth's example:** *"It was the best of times, it was the worst of times"* — Dickens, *A Tale of Two Cities*.

**How it works:** Antithesis ≠ contradiction. The two halves must mirror grammatically: noun against noun, verb against verb. Otherwise it's just a sentence with two ideas. Antithesis works because the brain is wired to retain pairs.

**Business-writing use:** Foundational for pitch language. *"We're not in the volume business, we're in the value business."* / *"Most consultants tell you what to do. We help you see what you're avoiding."* Useful for Three Uniques scripts and 90-Minute Meeting framing.

---

### 4. Merism

**Definition:** Naming the parts to invoke the whole. "Heaven and earth" means the universe. "Ladies and gentlemen" means everyone present. "Twenty-four-seven" means always.

**Forsyth's example:** *"Cannon to right of them, / Cannon to left of them, / Cannon in front of them"* — Tennyson, *The Charge of the Light Brigade*.

**How it works:** A merism feels more concrete and dramatic than the abstract whole it stands in for. "Search the heavens and the earth" is more vivid than "search everywhere."

**Business-writing use:** Eden Project language often uses theological merisms ("heart, soul, mind, strength"). EOS itself is built on a merism: *"Vision, People, Data, Issues, Process, Traction"* names six parts to invoke the whole of how a business runs. Good for Six Key Components rollout language.

---

### 5. The Blazon

**Definition:** Merism stretched to inventory the body of a beloved (or by extension, to inventory the parts of any admired thing). Forsyth calls it *"extended merism, the dismemberment of the loved one."*

**Forsyth's example:** *"Her yellow locks exceed the beaten gold; / Her sparkling eyes in heav'n a place deserve; / Her forehead high and fair of comely mold"* — Thomas Watson, *Hekatompathia*. The Song of Songs is the canonical religious example.

**How it works:** A blazon catalogs admired parts in sequence. Modern uses are usually parodic ("She had legs that wouldn't quit, eyes that could melt steel, and a smile that…"). It's hard to do straight without sounding dated.

**Business-writing use:** Limited. Useful in Eden Project teaching content (the Song of Songs as a model for embodied love), or in over-the-top tributes (a retiring leader's send-off). Generally avoid in business writing — it dates badly.

---

### 6. Synaesthesia

**Definition:** Describing one sense in terms of another. Crossing the wires deliberately.

**Forsyth's example:** Eduard Hanslick on Tchaikovsky's Violin Concerto: *"music that stinks to the ear."* The smell of victory. A loud color. A bitter look.

**How it works:** The brain registers a sensory mismatch and the phrase becomes vivid because the description is doing two things at once. Most powerful when the second sense is given to something abstract that has no native sense (the smell of *victory*, the taste of *defeat*).

**Business-writing use:** Excellent for emotionally charged moments — the sound of growth, the texture of a healthy team, the weight of a decision. Useful in Eden Project content where embodied/spiritual language overlaps. Use sparingly in EOS material.

---

### 7. Aposiopesis

**Definition:** Stopping a sentence in the middle. The unfinished thought signals overwhelming emotion (anger too big to express) or rhetorical menace.

**Forsyth's example:** *"I will have such revenges on you both, / that all the world shall — I will do such things — / What they are, yet I know not: but they shall be / the terrors of the earth"* — King Lear. Forsyth notes English punctuation marks aposiopesis with three dots: *"Tidy your room, or else…"* / *"If only…"*

**How it works:** The reader supplies the ending, which is always more powerful than what you would have written. The threat is bigger; the regret is heavier; the punchline is sharper.

**Business-writing use:** *"What happens in three years if you don't change anything? Well…"* Good for sales copy that creates implication rather than spelling out consequences. Risky in formal business writing — looks like a typo unless the reader is paying attention.

---

### 8. Hyperbaton

**Definition:** Putting words in an unnatural order on purpose. Forsyth calls it *"changing the logical order of words in a sentence."*

**Forsyth's example:** *"Stone walls do not a prison make"* — Richard Lovelace. Natural English: "Stone walls do not make a prison." Forsyth dryly adds *"in any case the statement is factually incorrect."* Yoda is one giant hyperbaton.

**How it works:** Disruption forces attention. The reader's brain trips over the wrong order and the phrase becomes memorable. English has limited tolerance for hyperbaton — overdo it and you sound like Yoda or a Victorian fop.

**Business-writing use:** Sparing. One line in a long post can carry it. *"To the leadership team, this matters most."* Generally too literary for emails or LinkedIn. Useful for the *one* line in a piece that needs to land.

---

### 9. Anadiplosis

**Definition:** The last word of one clause becomes the first word of the next. The chain pulls the reader forward.

**Forsyth's example:** *"We glory in tribulations also, knowing that tribulation worketh patience, and patience, experience, and experience, hope, and hope maketh man not ashamed"* — Romans 5:3-5. Star Wars version: *"Fear leads to anger. Anger leads to hate. Hate leads to suffering."* — Yoda.

**How it works:** Each word repeats and then transforms. The structure feels like cause-and-effect even when the logic is loose.

**Business-writing use:** Powerful for explaining systems where one thing leads to another. EOS framework example: *"Vision creates clarity. Clarity creates accountability. Accountability creates traction."* This is anadiplosis in service of teaching the V-T-H story. Consider for client-facing teach-ups and rollout decks.

---

### 10. Periodic Sentence

**Definition:** A sentence whose meaning is not complete until the final clause. The reader has to wait.

**Forsyth's example:** Kipling's *"If—"* is a single periodic sentence stretched across 32 lines. *"If you can keep your head when all about you / Are losing theirs and blaming it on you, / If you can trust yourself when all men doubt you… you'll be a Man, my son."* The "you'll be a Man" is the only main clause; everything before is subordinate suspense.

**How it works:** Suspended meaning creates tension. The reader pulls forward looking for the resolution. The longer the suspension, the more weight the final clause carries.

**Business-writing use:** Excellent for closing paragraphs of long-form posts where you've built a case. *"When a team is willing to be vulnerable in front of each other, willing to surface the issues no one wants to name, willing to set goals they're not sure they can hit — that's when EOS actually starts to work."* Avoid in emails (people skim). Good in Eden teaching content and LinkedIn essays.

---

### 11. Hypotaxis, Parataxis, Polysyndeton, Asyndeton

This chapter bundles four contrasting devices that govern how clauses relate.

**Hypotaxis** = many subordinate clauses, complex sentences with embedded logic. Sound: literary, dense, Henry James.
**Parataxis** = short simple sentences, no subordination. Sound: blunt, urgent, Hemingway. *"It was night. He was alone. He drank."*
**Polysyndeton** = repeating "and" between every item. *"And the rain came, and the wind blew, and the trees fell."* Genesis: *"And the earth was without form, and void; and darkness was upon the face of the deep."*
**Asyndeton** = removing conjunctions, items separated only by commas. *"I came, I saw, I conquered."*

**How they work:** Polysyndeton slows the reader down and makes a list feel infinite (and… and… and…). Asyndeton speeds the reader up and makes a list feel decisive (came, saw, conquered). Hypotaxis sounds intelligent and considered; parataxis sounds urgent and certain.

**Business-writing use:** Match to mood. **Asyndeton for clarity-of-action** ("Diagnose, decide, deploy"). **Polysyndeton for weight-of-history** ("And we built it, and we lost it, and we built it again"). **Parataxis for crisis** ("Sales fell. The team fractured. We knew."). **Hypotaxis for nuance** — careful here, business readers often skim past it.

---

### 12. Diacope

**Definition:** A word or phrase repeated, separated by one or two words.

**Forsyth's example:** *"Bond, James Bond."* Forsyth's astonishing observation: *"one of the greatest lines in the history of cinema is a man saying a name deliberately designed to be dull. The only possible explanation for the line's popularity is the way it is phrased… Wording, pure wording."* Other examples: *"Burn, baby, burn"* / *"Run, Forrest, run"* / *"O Captain! my Captain!"*

**How it works:** The brief interruption between the two repetitions creates a tiny rhythm — almost a heartbeat. The phrase becomes chant-like.

**Business-writing use:** Powerful for taglines and personal introductions. *"Revard. Duke Revard."* (don't actually do that). Better: *"It's traction, leadership-team traction, that we're after."* Use sparingly. One per piece is plenty.

---

### 13. Rhetorical Questions

**Definition:** A question asked without expecting an answer — but Forsyth divides them into five distinct types:

1. **No answer expected** ("Shall I compare thee to a summer's day?")
2. **No real answer possible** ("What's the point? Why go on?")
3. **Audience will give the answer you want** ("Which party cares about Britain?" — at your own party rally; the Monty Python *Life of Brian* "What have the Romans ever done for us?" scene is the comedy of this device misfiring)
4. **Asked and immediately answered by the asker** ("You ask, what is our aim? I can answer in one word: Victory!" — Churchill)
5. **Both questioner and answerer know the answer** (cop to speeding driver: "Did you think the speed limit didn't apply to you?")

**How it works:** Different types do different jobs. Type 4 (subjectio) is the most useful for written persuasion — it lets you raise the reader's likely objection and answer it in your own words.

**Business-writing use:** Type 4 is gold for LinkedIn and email. *"What does it actually take to break through the ceiling? Three things…"* Drive the reader's question and then answer it. Type 1 is gold for headlines. *"Why do leadership teams stall at $10M?"*

---

### 14. Hendiadys

**Definition:** An adjective-noun pair replaced by two nouns joined with "and." Instead of *"furious sound,"* you write *"sound and fury."* Instead of *"fearful trembling,"* Paul writes *"fear and trembling."*

**Forsyth's example:** *"It is a tale told by an idiot, full of sound and fury, signifying nothing"* — *Macbeth*. He notes Shakespeare averages roughly one hendiadys every 60 lines in *Hamlet*. Other examples: *"work out your salvation with fear and trembling"* (Paul, Philippians 2:12); *"Her beauty and the moonlight overthrew you"* (Leonard Cohen); colloquial *"house and home,"* *"nice and warm,"* *"good and ready."*

**How it works:** Two nouns joined by "and" feel weightier than an adjective + noun. The reader has to hold two concepts side by side instead of subordinating one to the other. This makes the phrase feel slightly off-balance and therefore memorable.

**Business-writing use:** Use deliberately. *"We're after vision and traction, not strategy and planning."* The "and" gives equal weight to two ideas where you'd normally subordinate one. Forsyth admits hendiadys is genuinely subtle and can be hard to identify. Use sparingly until it feels natural.

---

### 15. Epistrophe

**Definition:** Repeating the same word at the *end* of successive clauses. (Anaphora is the front-end version; epistrophe is the back-end.)

**Forsyth's example:** *"Wherever there's a fight so hungry people can eat, I'll be there. Wherever there's a cop beating up a guy, I'll be there. … And when our folk eat the stuff they raise and live in the houses they build — why, I'll be there."* — Tom Joad, *The Grapes of Wrath* (Steinbeck/Ford). Lincoln: *"…of the people, by the people, for the people"* (epistrophe + tricolon).

**How it works:** The reader expects variation at the end of each clause. Repeating the same word instead creates a thudding finality that registers as oath-like or prophetic.

**Business-writing use:** Excellent for closing emphasis. *"This is your business. The hires are your hires. The strategy is your strategy. The accountability is your accountability."* Strong in client-facing accountability talks. Risky in cold emails (sounds preachy).

---

### 16. Tricolon

**Definition:** Three parallel parts. The classical "rule of three." Forsyth observes that the third item is often noticeably longer than the first two — that asymmetry is part of why tricolons feel resolved.

**Forsyth's example:** France's national motto — *Liberté, égalité, fraternité*. Jefferson's *"life, liberty, and the pursuit of happiness."* Caesar's *"veni, vidi, vici."* Forsyth notes Obama's 2008 victory speech contained 21 tricolons. He also flags that Churchill's *"blood, toil, tears and sweat"* is a tetracolon (four) but is almost universally misremembered as "blood, sweat, and tears" — the brain prefers tricolons and edits the memory.

**How it works:** Three is the smallest number that creates a pattern. Two is a comparison. Three is a list. Four feels excessive. The first two items establish the pattern; the third either confirms or breaks it (a confirming third = "life, liberty, and happiness"; a breaking third = the comedic tricolon "wine, women, and song").

**Business-writing use:** The single most useful device in business writing. EOS itself is a tricolon: **Vision, Traction, Healthy.** "Right people in the right seats" is a tricolon ("right, right, seats"). Any list of three + parallel grammar = instantly more memorable than any list of two or four. Default to three whenever you can.

---

### 17. Epizeuxis

**Definition:** A word or phrase repeated *immediately,* with no words between.

**Forsyth's example:** *"The first rule of Fight Club is: you do not talk about Fight Club. The second rule of Fight Club is: you do not talk about Fight Club."* (Note this also uses anaphora and epistrophe.) Tony Blair on his three priorities for government: *"Education, education, education."* Real estate's *"Location, location, location."*

**How it works:** Immediate repetition signals overwhelming emphasis. The speaker can't move on; the point matters that much. It's the verbal equivalent of pounding the table.

**Business-writing use:** Very strong, very rare. One per piece, max. *"What we need is accountability. Accountability. Accountability."* Avoid in emails (looks unhinged). Good in keynote opening lines or rallying-cry moments.

---

### 18. Syllepsis

**Definition:** One word governing two phrases, but its meaning shifts between them. The word does double duty in two different senses.

**Forsyth's example:** *"Make love not war."* "Make" applied to love means one thing; "make" applied to war means another. *"He took his hat and his leave."* (took = picked up the hat; took = departed.) Forsyth says *"Some writers write about life; others, writing"* (he attributes this style of construction to himself in passing).

**How it works:** Syllepsis is the engine of wit. The reader's brain flips between the two meanings of the shared verb and gets a small "ha" of recognition. It's the foundation of the one-liner.

**Business-writing use:** Hard to deploy on demand but powerful when it lands. *"Most leadership teams lose patience and their best people in the same week."* (lose patience = emotional; lose people = literal). Excellent for LinkedIn closers. Practice generates more of these than effort does.

---

### 19. Isocolon

**Definition:** Two (or more) parallel clauses of equal length and matching structure. Often appears alongside antithesis or chiasmus.

**Forsyth's example:** *"Roses are red, violets are blue."* (Two clauses: subject-verb-color, subject-verb-color.) *"Easy come, easy go."* JFK: *"Let us never negotiate out of fear, but let us never fear to negotiate"* — isocolon plus chiasmus.

**How it works:** Equal length + parallel grammar = the brain reads the two halves as a complete unit. Asymmetric clauses sound clumsy. Symmetric clauses sound inevitable.

**Business-writing use:** The workhorse pattern of memorable business writing. *"Right people. Right seats."* / *"Smart team. Healthy team."* / *"Better data. Better decisions."* Combine with antithesis or tricolon for amplified effect.

---

### 20. Enallage

**Definition:** A deliberate grammatical "mistake" used for effect.

**Forsyth's example:** *"Mistah Kurtz — he dead"* — the closing line of *Heart of Darkness*. Should be "Mr. Kurtz is dead." The wrong grammar sounds final, native, true. *"We was robbed."* (Joe Jacobs, boxing manager.) Apple's *"Think different"* (should be "differently" — adverb).

**How it works:** A correctly grammatical sentence sounds processed. A deliberately ungrammatical one sounds like raw speech, raw feeling. The "error" is the message.

**Business-writing use:** Niche. Good for one-line emphasis when correct grammar would soften the point. *"This ain't strategy. This is survival."* Generally avoid in formal client writing — looks like an actual mistake.

---

### 21. A Divagation Concerning Versification

**Not a single device** — a chapter on meter and verse forms. Forsyth covers iambic pentameter (te-TUM te-TUM te-TUM te-TUM te-TUM, the natural "heartbeat" rhythm of English), the trochee (TUM-te), the dactyl (TUM-te-te), and the way famous lines often scan to standard meters. He notes that many memorable phrases are accidentally iambic.

**Why it matters:** Even prose has rhythm. Sentences that *feel* memorable usually scan into a natural meter. The reverse is also true — when a sentence won't sit right, often the issue is rhythm. Read aloud. Count beats.

**Business-writing use:** When a tagline or first line won't land, scan it. Often a one-syllable substitution unlocks rhythm. *"Right people in the right seats"* is roughly iambic. *"Hit the ceiling"* is trochaic — the falling stress mimics the impact. Forsyth's broader point: every phrase that earns its memorability obeys some rhythm, even if you can't name it.

---

### 22. Zeugma

**Definition:** One verb governing two (or more) parallel clauses where the verb only literally fits one. Closely related to syllepsis (Forsyth treats them as cousins; modern rhetoric textbooks merge or split them differently).

**Forsyth's example:** *"Some writers write about life; others, writing"* (verb "write" governs both halves but appears only once). The original of *"Hell hath no fury like a woman scorned"* — Congreve, *The Mourning Bride* — is *"Heav'n has no rage, like love to hatred turned, / Nor hell a fury, like a woman scorned"* — "hath" is shared across the two halves. The Beatles' *"You can't buy me love"* implicitly zeugmas "buy" against love.

**How it works:** The shared verb forces the reader to do mental work, which makes the phrase stick. Forsyth laments that *"poor zeugma"* is hard to pull off in modern English because we don't elide verbs as readily as Latin or Greek did.

**Business-writing use:** When you can drop the verb in the second half. *"Some leadership teams want growth; others, comfort."* Punchy and a touch literary. Risk: zeugma-via-elision can read as a typo if the reader isn't careful.

---

### 23. Paradox

**Definition:** A statement that appears self-contradictory but reveals a deeper truth on inspection.

**Forsyth's example:** Wilde — *"I can resist anything except temptation."* / *"The only way to get rid of a temptation is to yield to it."* Chesterton: *"The reformer is always right about what's wrong. He is generally wrong about what is right."*

**How it works:** The reader's brain registers a logical impossibility, leans in to resolve it, and finds the truth on the other side. A good paradox feels earned, not paradoxical-for-its-own-sake.

**Business-writing use:** Excellent for opening lines and counterintuitive coaching insights. *"The fastest way to grow is to slow down."* / *"Most leadership teams don't have a vision problem. They have a clarity problem."* Use carefully — paradox without payoff sounds like a Hallmark card.

---

### 24. Chiasmus

**Definition:** A-B-B-A structure: the second half reverses the order of the first. *"Ask not what your country can do for you, ask what you can do for your country."* (You-country becomes country-you.)

**Forsyth's example:** JFK's inaugural is the most famous English chiasmus. *"Beauty is truth, truth beauty"* (Keats, *Ode on a Grecian Urn*). *"It is not the strongest of the species that survives… but the one most responsive to change"* (this attributed to Darwin but Forsyth notes the phrasing is misattributed; the structure is chiastic).

**How it works:** The mirror structure feels like wisdom. The reader's brain registers symmetry and assumes profundity. Real chiasmus also tends to compress two ideas into a single insight.

**Business-writing use:** Powerful for closing lines. *"You don't get the team you want; you get the team you tolerate."* / *"Plans don't change the team; the team changes the plan."* Combine with antithesis (most chiasmus contains an antithesis).

---

### 25. Assonance

**Definition:** Repeated vowel sounds in nearby words.

**Forsyth's example:** *"The rain in Spain falls mainly on the plain"* (long-A throughout). *"How now, brown cow"* (long-OW). *"Rise and shine"* (long-I).

**How it works:** Like alliteration, but with vowels. Often invisible to the reader's conscious mind but heard by the ear. Rhyme is a special case of assonance + consonance at line-ends.

**Business-writing use:** Subtle. Mostly in headlines and names. *"Hire slow, fire fast"* (long-I, long-A). Test by reading aloud — assonance reveals itself.

---

### 26. The Fourteenth Rule

**Definition:** Forsyth's name for a specific principle: providing an unnecessarily *specific* number for emphasis. The book's actual title chapter — Forsyth himself coined "the fourteenth rule" as a humorous nod to his own device.

**Forsyth's example:** Why do we say *"The Seven Habits of Highly Effective People"* and not *"some habits"*? Why *"The Five Love Languages"* and not *"a few love languages"*? *"Twelve Steps."* *"Forty days and forty nights."* *"Three Uniques."* The arbitrary specificity confers authority — as if the author has done the counting and there are precisely that many.

**How it works:** Round numbers feel approximate. Specific numbers feel measured. *"Seven"* sounds rigorously discovered; *"some"* sounds like guesswork. Even when the number is invented, the specificity creates authority.

**Business-writing use:** This is a permanent move for content marketing. *"3 reasons your leadership team is stuck"* outperforms *"reasons your leadership team is stuck"* every time. Use *6 Key Components,* *5 Leadership Abilities,* *3 Uniques* — EOS is built on numbered frameworks for exactly this reason.

---

### 27. Catachresis

**Definition:** Forcing a "wrong" word into use where the right word doesn't exist or doesn't have the impact you want. Catachresis stretches a word past its literal meaning into metaphor — but more violently than ordinary metaphor.

**Forsyth's example:** Hamlet, on confronting his mother — *"I will speak daggers to her, but use none."* You don't literally *speak* daggers; the verb is yanked out of its normal usage. Milton — *"Blind mouths!"* (mouths can't be blind, and blindness has nothing to do with mouths — but the phrase is unforgettable).

**How it works:** The mismatch between the verb and its object creates a tiny shock. The reader fills in the metaphorical link. Done well, the phrase becomes more vivid than any "correct" alternative.

**Business-writing use:** Rare and risky. *"That meeting bled time."* / *"The org chart is screaming."* When it lands, it's unforgettable. When it misses, it sounds like a bad poetry slam. Reserve for high-stakes lines.

---

### 28. Litotes

**Definition:** Affirming something by denying its opposite. *"Not bad"* = good. *"Not unaware"* = aware. *"I wouldn't say no"* = yes please. Often involves a double negative.

**Forsyth's example:** *"'Would it be awfully wrong to tempt you with a drink?' 'I wouldn't say no.'"* Forsyth's verdict: *"Litotes is a form of understatement-by-negative"* and *"isn't the best figure to use when you're trying to be grand. Litotes does not stir the soul; it's more suited to stirring tea."*

**How it works:** Litotes sounds British and dry. It downplays while affirming, which gives the affirmation more credibility (the speaker isn't gushing). It's the rhetoric of restrained praise.

**Business-writing use:** Very British, very dry. Useful in advisory or skeptical-tone content. *"This isn't an unfamiliar problem."* / *"The leadership team wasn't displeased with the result."* Avoid in motivational copy — kills energy.

---

### 29. Metonymy and Synecdoche

**Definition:** Two related substitution figures.

- **Metonymy:** Use something *connected* to the thing you mean. *"The White House said…"* (means the U.S. President or administration). *"The crown decided…"* (means the monarch). *"Wall Street is jittery"* (means the financial industry).
- **Synecdoche:** Use a *part* to mean the whole, or the whole to mean a part. *"All hands on deck"* (hands = sailors). *"Top brains were on the case"* (brains = thinkers). *"Suits filled the room"* (suits = executives).

**Forsyth's framing:** *"The extreme form of metonymy is synecdoche, where you become one of your body parts."*

**How they work:** Both add concreteness and (often) drama. "Wall Street" is more vivid than "the financial sector." "All hands" is more vivid than "all sailors."

**Business-writing use:** Constant. *"The org chart got fixed when the leadership team finally talked."* (org chart = organizational structure.) *"DFW manufacturing is feeling the pinch."* (DFW manufacturing = manufacturing companies in the DFW area.) Most business prose already uses these unconsciously. Notice them and dial up.

---

### 30. Transferred Epithets

**Definition:** Attaching an adjective to the *wrong* noun on purpose. The adjective belongs to a different (often a person) implied by the noun.

**Forsyth's example:** *"A sleepless night"* (the night isn't sleepless; the person is). *"The condemned cell"* (the cell isn't condemned; the prisoner is). *"A lonely room"* (the room can't be lonely; the occupant is).

**How it works:** The adjective leaps to where it doesn't belong, and the reader's brain reroutes it back to the implied person. The mental work makes the phrase memorable. It's also more compact than spelling the relationship out.

**Business-writing use:** *"A frustrating quarter."* (You're frustrated, not the quarter — but the phrase compresses the feeling.) *"An anxious roadmap."* *"A confident scorecard."* Useful in coaching language and Eden Project content.

---

### 31. Pleonasm

**Definition:** Deliberately using more words than strictly necessary. The opposite of concision — and Forsyth's chapter title itself is *"Pleonasm: The use of unneeded words."*

**Forsyth's example:** *"Free gift."* / *"ATM machine."* / *"PIN number."* / *"I saw it with my own eyes."* / *"True fact."* Most pleonasm is invisible because it's idiomatic.

**How it works:** Pleonasm signals emphasis or sincerity. *"I saw it with my own eyes"* registers as more credible than *"I saw it,"* even though "with my own eyes" adds no information. The redundancy is the message: *I'm not exaggerating.*

**Business-writing use:** Selectively. *"Your actual, real-world results."* / *"The honest, unvarnished truth."* In business writing pleonasm is usually a flaw — but pleonasm-for-emphasis is a known move that adds credibility when the reader is skeptical.

---

### 32. Epanalepsis

**Definition:** Beginning and ending a clause with the same word. The bookend.

**Forsyth's example:** Robert Burns — *"Man's inhumanity to man."* Forsyth notes the phrase wouldn't have lasted if Burns had written "Man's inhumanity to others." The repetition of "man" at the beginning and end creates closure. Other examples: *"Nothing can be created from nothing"* (Lucretius). *"The king is dead, long live the king."*

**How it works:** The repeated word at start and end creates a sealed unit. The phrase feels complete and self-contained — almost proverbial.

**Business-writing use:** Excellent for one-line propositions. *"Vision drives traction; traction proves vision."* (vision begins, vision-ish ends) — actually that's a chiasmus near-miss. Better epanalepsis: *"People hire people."* / *"Culture eats culture."* Rare in business writing because it sounds writerly. Use for headline-level emphasis.

---

### 33. Personification

**Definition:** Giving human qualities, actions, or feelings to non-human things — abstract concepts, objects, ideas.

**Forsyth's example:** Wordsworth's *"I wandered lonely as a cloud"* — clouds are not lonely. *"Justice is blind."* *"The market is nervous."* *"Death came knocking."*

**How it works:** Abstractions are hard to remember. Personified abstractions stick because the brain processes them as characters, not concepts.

**Business-writing use:** *"The market is impatient."* *"The org chart is exhausted."* *"Your scorecard is trying to tell you something."* Strong in coaching language and persuasive emails. Risk of cliché — every business writer reaches for personification.

---

### 34. Hyperbole

**Definition:** Calculated exaggeration. Not lying — exaggerating so obviously that the reader knows you mean it figuratively.

**Forsyth's example:** *"I've told you a million times."* *"My grandmother could code faster than this team."* *"The line was a mile long."*

**How it works:** Hyperbole's job is *emphasis,* not deception. The reader's brain registers the exaggeration, recalibrates, and concludes "they really mean it." The emotional charge is real even though the literal claim is false.

**Business-writing use:** Constantly underused in business writing because writers fear sounding unprofessional. *"This decision will haunt us for a decade."* *"The team's been begging for this clarity forever."* Calibrate to your context — Eden content tolerates more hyperbole than EOS proposals.

---

### 35. Adynaton

**Definition:** Hyperbole pushed past the point of physical impossibility. The exaggeration is so extreme it's clearly figurative.

**Forsyth's example:** *"When pigs fly."* *"When hell freezes over."* *"I'll do that the day after never."* Forsyth's reviewer-cited line: *"If you want to resist this book's charm, you might as well try to go skinny dipping on the sun."*

**How it works:** The impossibility is the point. The reader processes "when pigs fly" not as a flying-pig prediction but as an emphatic *never.* Adynaton is hyperbole for closers.

**Business-writing use:** Punchline material. *"That'll happen the day my Visionary stops adding new ideas at the end of every meeting."* / *"They'll IDS that issue when the Board of Directors starts running L10s."* Good in Eden teaching content (adynaton is biblical — *"Easier for a camel to pass through the eye of a needle…"* is adynaton).

---

### 36. Prolepsis

**Definition:** Forsyth uses "prolepsis" for one of its five classical meanings: **using a pronoun before naming the noun it refers to.** Normally you introduce a noun then refer back with a pronoun. Prolepsis reverses this — pronoun first, noun later — creating mystery.

**Forsyth's example:** Philip Larkin — *"They fuck you up, your mum and dad."* (You don't know who "they" are until the second half.) Stevie Smith — *"Nobody heard him, the dead man, / But still he lay moaning."* (the "him" is unidentified for a beat). Forsyth: *"It is an interesting device, this Prolepsis."* (Note: that sentence itself is prolepsis.)

**How it works:** The unfilled pronoun creates a tiny gap that the reader's brain demands to fill. By the time the noun arrives, the reader is leaning in.

**Business-writing use:** Strong opening line move. *"It changes everything, this conversation about exit readiness."* / *"They're the most important hires you'll ever make, the first three on your leadership team."* Use sparingly — too much prolepsis sounds affected.

**Note on classical confusion:** "Prolepsis" has at least five different meanings in classical rhetoric, including "anticipating an objection" and "describing a future state as if already happening." Forsyth picks the pronoun-first sense. If you research "prolepsis" elsewhere, expect different definitions.

---

### 37. Congeries

**Definition:** A heap of nouns or adjectives — a deliberate, slightly excessive piling-on.

**Forsyth's example:** Prospero in *The Tempest* — *"The cloud-capped towers, the gorgeous palaces, / The solemn temples, the great globe itself."* Forsyth's framing: *"Congeries is Latin for a heap, and in rhetoric it applies to any piling up of adjectives or nouns. List means exactly the same thing, but it has none of the exoticism of congeries, no spice, no adventure, no derring-do, no whiff of the palm tree and the jungle, no pizzazz, no fairy-dust, no magic."* (That sentence is itself a congeries, demonstrating the device.)

**How it works:** The overflow signals abundance. A list of three is a tricolon; a list of seven or eight is congeries. The point isn't to enumerate — it's to overwhelm.

**Business-writing use:** When you need to convey overwhelm or abundance. *"The chaos of the last quarter — the missed numbers, the customer escalations, the late-night Slack messages, the resignations, the back-channel arguments, the rework — was the cost of running without an Accountability Chart."* Strong for storytelling moments in LinkedIn posts.

---

### 38. Scesis Onomaton

**Definition:** A sentence with no main verb. The verb is implied or simply absent.

**Forsyth's example:** *"Space: the final frontier"* — *Star Trek*. *"Michaelmas term lately over, and the Lord Chancellor sitting in the Lincoln's Inn Hall"* — opening of *Bleak House* (Dickens). *"Beyond the Pale."* *"From Russia, with love."*

**How it works:** Verbless sentences feel incomplete in a useful way. They register as titles, declarations, invocations rather than statements. The missing verb forces the reader to supply context.

**Business-writing use:** Headlines and section openers. *"DFW Manufacturing in 2026: more demand, less labor."* / *"Three Uniques. One company. No apologies."* Common in marketing. Use deliberately — overuse makes prose feel ad-copy-cheap.

---

### 39. Anaphora

**Definition:** Beginning successive clauses or sentences with the same word(s). The front-end mirror of epistrophe.

**Forsyth's example:** *"We shall fight on the beaches, we shall fight on the landing grounds, we shall fight in the fields and in the streets, we shall fight in the hills; we shall never surrender"* — Churchill. MLK's *"I have a dream"* sequence. *"Now is the time… Now is the time… Now is the time…"* — also MLK.

**How it works:** Anaphora is the king of rhetorical figures. The repeated front gives each clause a fresh launch and creates rhythm, momentum, and emotional accumulation. It's the structure of every great rallying speech in English.

**Business-writing use:** Probably the highest-leverage device in business writing. *"This is what your leadership team needs. This is what your scorecard reveals. This is what your accountability chart demands."* Use in Annual session opens, big LinkedIn essays, prospect emails that need to land hard. Stack three anaphoric sentences and you have an instant punch.

---

## What's NOT Clear Yet

This section honors the research-with-confidence skill's mandate — every research project has unknowns, and naming them is the difference between research and confident-sounding summary.

1. **Forsyth's exact wording vs. paraphrase.** I've drawn from Wikipedia summaries, reviewer blogs, and the Internet Archive scan. The book's *exact* phrasing on certain definitions (especially the more idiosyncratic ones — Hendiadys, Catachresis, The Fourteenth Rule) may differ slightly from the renderings here. **Recommended:** when this becomes a skill, verify against the physical book for the specific phrasing on at least the top 10 most-used devices.

2. **Forsyth's specific examples for chapters 21 (Versification), 26 (The Fourteenth Rule), and 38 (Scesis Onomaton).** These chapters are less heavily quoted in online summaries. The general concept is well-corroborated, but Forsyth's *specific* extended examples are not in my sources. The examples I've provided (Star Trek, "Seven Habits") are confirmed in reviewer blogs but may not be Forsyth's primary illustrations.

3. **The Prolepsis classical-definition tangle.** Forsyth picks one of five meanings of "prolepsis" and treats it as primary. If a future skill user wants to broaden the definition (e.g., to include "anticipating an objection" — which is what most American rhetoric textbooks call prolepsis), that would be a deliberate departure from Forsyth's usage. Worth flagging for the skill design.

4. **The total count of distinct devices.** The book has 39 chapters, but several chapters bundle multiple figures (Ch 11 covers four; Ch 29 covers two; Ch 5 is a sub-type of Ch 4). Distinct devices = ~42–44 depending on how you count. Forsyth's preface sometimes says "over 30," sometimes "39." Not a discrepancy worth resolving — just note it.

5. **Modern updates.** The book is 2013. Some of Forsyth's pop examples (Katy Perry references in particular) are aging. A skill could pair each device with a *current* example (TikTok-era, post-2020) to keep it fresh. That's outside this research's scope but worth flagging for skill design.

6. **The Henry Peacham / George Puttenham original Renaissance sources.** Forsyth references *The Garden of Eloquence* (Peacham, 1577) and Puttenham's 1589 work as the English-language translations of classical rhetoric. If the skill ever wants primary-source backup, those Renaissance handbooks are the actual ancestors. Modern equivalent: Silva Rhetoricae (rhetoric.byu.edu) is the standard online classical-rhetoric reference and would be a Tier-1 cross-check for any device's classical lineage.

---

## Relevance to Duke's Writing

Connecting findings to Duke's actual writing channels:

**LinkedIn carousels and posts (TrueSpace 2.8x growth study, EOS evergreen content):**
Highest-leverage devices are **anaphora** (open with three "Now is the time…" lines), **tricolon** (every list goes in threes), **isocolon** (parallel structure on every key claim), **The Fourteenth Rule** (always quantify — *3 reasons, 5 signals, 7 patterns*), and **rhetorical questions of the subjectio type** (raise the reader's question, then answer it). These five devices alone will materially upgrade LinkedIn output without sounding writerly.

**Post-Quarterly emails and Pre-FocusDay emails:**
**Anadiplosis** for explaining the chain of how the next session builds on the last (*"vision creates clarity, clarity creates accountability, accountability creates traction"*). **Tricolon** for objectives and homework lists. **Litotes** when softening a critical observation. Avoid heavy literary devices (hyperbaton, hendiadys) in emails — readers skim.

**Three Uniques scripts and V/TO Marketing Strategy language:**
**Antithesis** (*"We don't sell strategy, we install systems"*). **Polyptoton** (*"We don't just sell systems. We systematize the way you sell."*). **Tricolon** is the only viable structure for the Three Uniques themselves — that's why the EOS framework is V-T-H, three uniques, six key components. The Fourteenth Rule everywhere.

**Eden Project teaching content:**
The full toolkit unlocks here. **Synaesthesia, blazon, hyperbole, adynaton, anaphora, congeries, personification** — Eden material has the literary register that lets these breathe. The Song of Songs is built on blazon. The Sermon on the Mount is built on anaphora. Eden teaching content can lean into the literary devices that EOS material can't.

**Prospect dossier intros and first-touch emails:**
**Prolepsis** for opening lines that create mystery (*"They never see it coming, the leadership teams that hit the ceiling"*). **Diacope** for natural personal introductions (*"Revard, Duke Revard"* — kidding; but *"It's traction, leadership-team traction, that we're after"* works). **Asyndeton** for verbs of action (*"Diagnose, decide, deploy"*).

**90-Minute Meeting opening and closing language:**
**Anaphora** to drive the close (*"This is what EOS does. This is what changes. This is what you'll feel."*). **Antithesis** for the opening reframe (*"You don't have a strategy problem. You have an alignment problem."*). **Tricolon** for the V-T-H summary every single time.

---

## Source List

Sources consulted, ordered by relevance and confidence weight:

| Source | Date | Tier | Notes |
|--------|------|------|-------|
| Forsyth, *The Elements of Eloquence* — Internet Archive full-text scan | 2013 | **Primary** | The book itself. URL: archive.org/details/elementsofeloque0000fors |
| Wikipedia — *The Elements of Eloquence* article | Updated 2025 | Tier 1 (for book summary) | Full chapter list and Forsyth's specific examples for ~30 devices. URL: en.wikipedia.org/wiki/The_Elements_of_Eloquence |
| Penguin Random House — official publisher page | 2014 | Primary | Confirms "39 succinct chapters," includes Wall Street Journal review excerpts. URL: penguinrandomhouse.com/books/316760 |
| Barnes & Noble — published TOC with page numbers | 2014 | Primary | Confirmed page numbers for chapters 29-39. URL: barnesandnoble.com/w/the-elements-of-eloquence-mark-forsyth |
| The Key Point — *Elements of Eloquence* review | 2016 | Tier 2 | Direct quotes from book on Litotes, Synecdoche, Epanalepsis, Aposiopesis, Prolepsis. URL: thekeypoint.org/2016/10/02/the-elements-of-eloquence |
| Kadavy.net — book summary (Love Your Work podcast) | 2022 | Tier 2 | Summary with Forsyth's tricolon-vs-tetracolon Churchill point and Hendiadys examples. URL: kadavy.net/blog/posts/elements-of-eloquence-summary |
| Sabidius Classics Blog — Hendiadys analysis | 2017 | Tier 2 | Cites Forsyth directly on the *sound and fury* example; cross-checked against classical Latin rhetoric. URL: sabidius.blogspot.com |
| Leo Burghaus blog — *Elements of Eloquence* notes | 2024 | Tier 3 | Useful for Forsyth's quirky Prolepsis definition. URL: leoburghaus.com |
| Goodreads reviews + Forsyth-style examples | various | Tier 3 | Useful for cross-checking Forsyth's voice and a reviewer's full paraphrased TOC entries 19-35. URL: goodreads.com/book/show/17415726 |
| Stranger Collective — review | 2018 | Tier 3 | Confirms Forsyth's "blindfolded cooks" framing of why this matters. URL: stranger-collective.com |
| Flintoff.org — speechwriter's notes on Forsyth | 2022 | Tier 3 | Best source for Prolepsis's five classical meanings and Forsyth's preferred sense. URL: flintoff.org/elements-of-eloquence-WTCTW-5 |
| Grokipedia — *Elements of Eloquence* | 2026 | Tier 3 | AI-generated summary; useful as a corroboration check, treated cautiously per the skill's "AI content recycles outdated facts" guardrail. URL: grokipedia.com/page/The_Elements_of_Eloquence |
| Bookey app PDF summary | undated | Tier 3 | Lower weight; flagged as "undated" per the skill's source-quality guidance. URL: cdn.bookey.app |

**Echo-chamber check:** All non-primary sources cite the book directly (with quoted passages). Where multiple Tier 3 sources agreed, they generally agreed on Forsyth's actual examples rather than recycling each other. The Wikipedia article appears to be the seed for several blog summaries' chapter-level definitions, so I've weighted Wikipedia + the actual published TOC + reviewer blogs that quote the book directly as the strongest triangulation. **Suspicious-consensus check:** none of the sources offered any major contrarian read of Forsyth's claims — but this is appropriate for a book summary, not a controversial topic.

**Recommended next step before skill conversion:** physical-book verification on the top 10 most-used devices' exact phrasing (Forsyth's voice is part of the value), and one pass through Silva Rhetoricae (rhetoric.byu.edu) to add classical-source citations for any device where the skill user wants academic backup.
