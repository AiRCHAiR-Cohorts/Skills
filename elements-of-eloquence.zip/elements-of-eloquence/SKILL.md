---
name: elements-of-eloquence
description: >
  Apply Mark Forsyth's 39 rhetorical schemes from The Elements of Eloquence to
  diversify Duke's blog posts and LinkedIn content so it doesn't read like
  formulaic AI writing. Trigger whenever Duke asks to write, draft, edit, punch
  up, polish, or rewrite a LinkedIn post, LinkedIn carousel, blog post, or
  long-form essay. Also trigger on phrases like "make this less AI-sounding,"
  "diversify this writing," "this sounds too formulaic," "rework this draft,"
  "give me a memorable line," "punch up this hook," "tighten this opening,"
  "this needs a stronger close," or any request to make written content more
  memorable, more varied, or more human-sounding. Trigger on first-touch even
  when Duke just says "write me a LinkedIn post about X" or "draft a blog post
  on Y" — apply this skill from the first draft, not as a polish pass. Do NOT
  use for emails (which have their own skills), session prep, prospect dossiers,
  or any deliverable that is not a blog post or LinkedIn post.
---

# The Elements of Eloquence

A skill for writing Duke's blog posts and LinkedIn content using the full diversity of Mark Forsyth's 39 rhetorical schemes — not the same three devices AI defaults to.

## Why this exists

AI-generated writing has a tell. It's the same handful of rhetorical moves repeated across every post: the "It's not just X — it's Y" antithesis, the perfectly parallel tricolon in every paragraph, the em-dash for every aside, the "Here's the thing" opener, the "And that's why" closer. Readers' pattern-recognition has caught up. Posts that lean on these formulas now register as machine-written within two lines.

Forsyth catalogs **39 distinct schemes** the Greeks and Romans systematized and Shakespeare exploited. AI defaults to maybe four of them. The remaining 35 are Duke's competitive advantage — the pool of patterns that produces writing readers can't tell wasn't written by a human who has read a lot of Shakespeare.

The job of this skill is to **diversify** — to pick from across all 39 schemes, vary device density between paragraphs, and explicitly avoid the 10 AI-tell formulas listed below.

## When this triggers

Whenever Duke asks for blog or LinkedIn content. From the first draft. Not as a polish pass. Trigger words include: write, draft, post, blog, article, carousel, hook, opening, close, edit, rewrite, punch up, polish, tighten, diversify, rework, "less AI-sounding."

Do NOT trigger for: emails, prospect dossiers, session prep, V/TO drafts, Three Uniques scripts (these are handled by `three-uniques-script`), Eden teaching content (different register — handle separately if needed), or any internal document.

## The workflow

### Step 1 — Read the brief

Before writing, identify three things about the piece:

1. **Job to be done.** Is it teaching, persuading, telling a story, opening a conversation, or making a single memorable point? Each calls for different devices.
2. **Length and form.** A 200-word LinkedIn post tolerates 2–3 devices total. A 1,200-word blog post can carry 8–12 devices spaced across paragraphs. Carousels are different again — each slide is a stand-alone unit and benefits from its own device.
3. **Duke's voice.** Pastoral foundation, marketplace credibility, intellectually creative, fact-thorough, dry rather than chipper. Devices should serve this voice, not paste a different one over it.

### Step 2 — Select devices from at least 4 families

The 39 devices fall into eight families. The fastest way to sound formulaic is to pull every device from one or two families. The fastest way to sound varied is to pull from at least four.

The eight families:

- **Sound repetition:** Alliteration, Assonance, Versification (rhythm)
- **Word repetition:** Polyptoton, Anadiplosis, Diacope, Epistrophe, Anaphora, Epizeuxis, Epanalepsis
- **Structural parallelism:** Antithesis, Tricolon, Isocolon, Chiasmus, Periodic Sentence, Polysyndeton, Asyndeton, Hypotaxis, Parataxis
- **Word-order disruption:** Hyperbaton, Enallage, Prolepsis, Scesis Onomaton, Hendiadys
- **Substitution / reference:** Merism, Blazon, Synaesthesia, Metonymy, Synecdoche, Transferred Epithet, Personification, Catachresis
- **Wit and twist:** Syllepsis, Zeugma, Paradox
- **Magnification / diminishment:** Hyperbole, Adynaton, Litotes, Pleonasm, The Fourteenth Rule, Congeries
- **Audience engagement:** Rhetorical Question, Aposiopesis

For a typical 800-word LinkedIn essay, pick one device from each of 4–5 families. For a blog post, 6–8 families. Don't use the same device twice in a short piece.

### Step 3 — Vary device density

Real writing breathes. Some paragraphs ornament-heavy, some plain. AI writing tends to apply the same level of polish to every line — the rhetorical equivalent of saturated color in every photo.

The pattern that reads as human:
- Opening line: device-rich (this is where memorability is purchased)
- Setup paragraph: mostly plain prose, maybe one subtle device
- Mid-piece argument paragraphs: 1–2 devices each
- The pivot or counterpoint: device-rich again
- Closing line: the strongest device of the piece

Avoid uniform rhythm. A short fragment after a long sentence punches harder than another long sentence. A bare declarative after three ornate ones lands like a hammer.

### Step 4 — Write, then audit against AI-tells

Draft the piece, then run it through the AI-tell guardrails below. Fix anything that triggers a guardrail.

### Step 5 — Read aloud (mentally)

Forsyth's chapter on versification makes the underlying point: sentences that work scan into a rhythm, even in prose. Read each device-bearing line aloud. If it stumbles, the rhythm is wrong, not the words. Often a one-syllable substitution unlocks it.

---

## The Top 12 Devices for Blog/LinkedIn

These are the highest-leverage devices for this medium. Default to these. Reach for the other 27 when one of these would feel forced or when the piece has earned ornament.

### 1. Anaphora — same opening word in successive sentences

The single most useful pattern in long-form persuasive writing. Reach for it when building toward a point.

> "This is what your scorecard reveals. This is what your accountability chart demands. This is what most leadership teams refuse to look at."

Stack three. Four if the rhythm carries. More than four reads as preacher-mode.

### 2. Tricolon — three parallel parts

Default move when a sentence wants a list. The third item should be slightly longer or slightly different from the first two — that's the asymmetry that makes the brain register the pattern as resolved.

> "Right people. Right seats. The discipline to admit when neither is true."

Don't default to perfectly symmetric tricolons in every paragraph. That's the AI tell. Mix tricolons with two-part isocolons and with single declarative sentences.

### 3. Isocolon — two parallel clauses, equal length

Workhorse pattern. Most memorable lines in Western prose are isocolons.

> "Plans don't change the team. The team changes the plan."

Combine with antithesis (most isocolons contain one) or chiasmus (the closing-line move).

### 4. Antithesis — opposites in parallel structure

Powerful when used sparingly. Avoid the AI formula "It's not just X — it's Y." Real antithesis varies — best/worst, was/wasn't, do/don't, then/now.

> "Most consultants give you the answer. The good ones give you the question."

### 5. The Fourteenth Rule — specific numbers

Headlines and hooks. *"3 reasons your leadership team is stuck"* outperforms *"reasons your leadership team is stuck"* every time. Not because three is the right count — because the specificity confers authority.

> "37 leadership teams in three years. Same pattern every time."

Use real numbers when you have them. Invent specifics when the alternative is "many" or "several."

### 6. Diacope — repeated word with one or two words between

The "Bond, James Bond" pattern. Creates a tiny heartbeat in a phrase.

> "It's traction — leadership-team traction — that we're after."

One per piece is enough. Two is showing off.

### 7. Asyndeton — list with no conjunctions, just commas

Speeds the reader up. Gives lists the feel of decisive action.

> "Diagnose. Decide. Deploy."

Pairs naturally with tricolon. Compare *"diagnose, decide, and deploy"* (with conjunction = soft) against *"diagnose, decide, deploy"* (without = decisive). The conjunction is the difference between a memo and an order.

### 8. Polysyndeton — list with "and" between every item

The opposite move. Slows the reader down. Makes a list feel weighted, accumulating, biblical.

> "And we built it, and we lost it, and we built it again, and we lost it again, and we built it the third time, and the third time it held."

Use rarely. Once a piece. The contrast against asyndeton is the engine.

### 9. Rhetorical question (subjectio type) — ask, then answer

Drives engagement. Forsyth's Type 4 — you ask the reader's likely question and answer it in your own words.

> "What does it actually take to break the ceiling? Three things. None of them are what most owners reach for first."

The Type 1 *"Shall I compare thee…"* unanswered version works for headlines. Type 4 works inside the body.

### 10. Polyptoton — same root, different forms

Subtle. Sneaks past the reader as natural prose while still creating the undertow of repetition that makes a phrase feel inevitable.

> "We don't just sell systems. We systematize the way you sell."

Sell/sell, system/systematize. Two words doing the work of repetition without registering as repetition.

### 11. Chiasmus — A-B-B-A reversal

The closing-line move. Almost always contains an antithesis. Feels like wisdom.

> "You don't get the team you want. You get the team you tolerate."

One per piece. Place at the end. Earn it.

### 12. Prolepsis (Forsyth's sense) — pronoun before its noun

Opens a piece with mystery. The reader doesn't know who or what "they" / "it" / "this" refers to until the second clause.

> "They show up around year seven, the cracks. Quiet at first. Then everywhere."

Use only at openings. Never mid-piece — the pronoun has been resolved by then.

---

## AI-Tell Guardrails

Forbid these patterns. They are the rhetorical equivalent of typing in Comic Sans.

### Tell #1 — "It's not just X — it's Y"

The single most overused AI antithesis. Real antithesis varies its structure. If a piece uses this construction more than once, kill all but one — and even that one should probably go.

❌ "This isn't just a leadership problem — it's a clarity problem."
✅ "Most teams call it a leadership problem. It's almost always a clarity problem."

### Tell #2 — Em-dash for every aside

Em-dashes are powerful but AI overuses them as the universal aside-marker. Vary punctuation: parentheses for genuine asides, commas for short ones, colons for setup-payoff, full sentences for emphasis.

A piece should average no more than one em-dash per 200 words. If draft has more, cut.

### Tell #3 — "Here's the thing" / "Here's what most people miss" / "Picture this"

Generic AI hooks. Never use them. Open with prolepsis, a specific number, a concrete image, a paradox, or a direct question. Anything but the formulas.

### Tell #4 — Tricolon in every paragraph

Tricolons are powerful precisely because they punctuate. If every paragraph has one, none of them land. Maximum two tricolons per LinkedIn post; three per blog post. The other paragraphs use isocolon, single declaratives, or no parallel structure at all.

### Tell #5 — Bold-everything-important

Bolding individual words inside paragraphs is AI's tell that it's worried the reader won't catch the point. If the writing is doing its job, the emphasis comes from the rhetoric, not from typography. Use bold only for genuine section headings — never for inline emphasis.

### Tell #6 — "And that's why…" closer

AI loves to summarize at the end. Don't. Either close with a chiasmus, a paradox, an aposiopesis (trailing off), a single declarative, or a direct address. Never with a recap.

### Tell #7 — Generic CTA ("What's your take?" / "Drop a comment")

If the post earned engagement, the engagement happens. If it didn't, asking won't fix it. Skip the CTA or make it specific to the piece.

### Tell #8 — Even paragraph length

AI drafts paragraphs of similar length. Real writing varies wildly: a one-sentence paragraph next to a five-sentence paragraph next to a fragment. Vary deliberately.

### Tell #9 — Opening with a question

Especially "Have you ever…" or "What if…" — these are tired. If a question opens, make it specific and unexpected. Better: open with a flat declarative or a prolepsis.

### Tell #10 — "In a world where…" / "In today's landscape…" / "Now more than ever"

Contextual scene-setting AI loves. Cut. Open in the middle of the action.

---

## Worked Examples

Each example shows the same idea written three ways: plain (functional but flat), formulaic-AI (technically correct but tells), and Forsyth-diversified (varied devices, no tells).

### Example 1 — LinkedIn opening on "hitting the ceiling"

**Plain:**
> Most companies stop growing at certain points. Leaders need to recognize this and adjust their approach.

**Formulaic-AI:**
> Here's the thing about growth — it's not just about working harder. It's about working smarter. Companies that hit the ceiling face three challenges: people, processes, and priorities. The teams that break through? They master all three.

**Forsyth-diversified:**
> Every leadership team hits the ceiling. The question isn't whether — it's when, and what they do once they hit it. Most teams hire faster. Some teams strategize harder. The teams that actually break through do something different: they get smaller before they get bigger.

What's working in the diversified version: epanalepsis-adjacent opening (every leadership team / hits the ceiling), antithesis without the AI formula (whether/when), tricolon with a breaking third (hire faster / strategize harder / something different), closing paradox (smaller before bigger). Five devices from four families. No "It's not just," no em-dashes, no "Here's the thing."

### Example 2 — Blog post hook on Three Uniques

**Plain:**
> Most companies struggle to articulate what makes them different. The Three Uniques framework helps with this.

**Formulaic-AI:**
> Here's the truth — most companies can't articulate what makes them different. They list features. They list values. They list everything except what actually matters. The Three Uniques framework changes that.

**Forsyth-diversified:**
> Ask a CEO what makes their company different and you'll get an inventory. Features. Values. Awards. Process diagrams. Everything except an answer. The Three Uniques framework is built on a different idea — that "different" can only be three things, and that the work is figuring out which three.

What's working: opens in the middle (no contextual setup), congeries (the pile-up: features, values, awards, process diagrams), polyptoton (different / different), specific number (three), aposiopesis-adjacent rhythm with the fragment "Everything except an answer." Six devices. No tells.

### Example 3 — LinkedIn closing line

**Plain:**
> If you're a leader, the right time to fix this is now.

**Formulaic-AI:**
> So here's my question to you: are you ready to do the work? The leaders who break through aren't the smartest — they're the most willing. And that's why I do this work.

**Forsyth-diversified:**
> The leaders I work with don't fix this when it's convenient. They fix it when it's necessary. By then, the necessary is usually overdue.

Chiasmus-adjacent (convenient/necessary, necessary/overdue), polyptoton (necessary / necessary), isocolon. Three devices in three sentences. Closes without summarizing or asking for engagement.

---

## When to consult the full reference

The bundled reference at `references/full-device-reference.md` contains all 39 devices with definitions, Forsyth's canonical examples, classical confidence-rating, and full source citations. Read it when:

- A piece needs a device not in the Top 12 above (e.g., synaesthesia for an Eden-adjacent post, congeries for a long-tail piling-up paragraph, hendiadys for a literary-feel sentence)
- Verifying the canonical Forsyth example for a specific device before quoting it
- Looking up which family a device belongs to
- Understanding edge cases (e.g., the difference between zeugma and syllepsis, or which of the five classical meanings of "prolepsis" Forsyth uses)
- Showing Duke the source if he asks how a device is used historically

The reference's table of contents covers all 39 chapters in book order plus a functional index ("I want to write a phrase that…") and a complete source list.

---

## Final note on voice

Duke's writing voice has specific characteristics: pastoral undertone, marketplace credibility, intellectually thorough (Fact Finder 9), influences-by-expertise rather than charisma, dry rather than enthusiastic, often surfaces the truth that someone has been avoiding. The devices serve this voice. They don't replace it.

A piece can be technically full of Forsyth devices and still feel wrong if it sounds like someone other than Duke. The test isn't "did I use enough devices" — it's "does this read as something Duke would have written if he'd had unlimited time and a deep knowledge of Shakespeare." When in doubt, fewer devices and more clarity. The point of the skill isn't ornament. It's variety in service of memorability.
